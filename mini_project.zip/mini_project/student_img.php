<?php
 include"connection.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $dir="images/";
    $filePath=$dir .basename($_FILES["imgFile"]["name"]);
    $isUpload=true;
    $imageFileType=strtolower(pathinfo($filePath,PATHINFO_EXTENSION));
    // CHECK FILE IS PDF
if(isset($_POST["submit"])){
    $check=getimagesize($_FILES["imgFile"]["temp_name"]);
    if($check!==false){
        echo "file is an image" .$check["mime"]."<br>";
        $isUpload=true;
    }
    else{
        echo "file is not an image .<br>";
        $isUpload=false;
    }
   
}
// code to check file already present
if(file_exists($filePath)){
    echo "sorry file is already exists.<br>";
    $isUpload=false;
}
// code to ensure file size
if($_FILES["imgFile"]["size"]>500000){//500kb
echo "sorry your file is too large.<br>";
$isUpload=false;
}
// code to check file  format
if($imageFileType !="jpg"
&& $imageFileType !="png"
&& $imageFileType !="jpeg"
&& $imageFileType !="gif"){

    echo "sorry , only jpg, png,gif are allowed".
    $isUpload=false;
}
// checking flag set to upload
if(!$isUpload){
echo "sorry, your file is not uploaded.<br>";}
else{
    if(move_uploaded_file($_FILES["imgFile"]["tmp_name"],$filePath)){
$filename=  htmlspecialchars(basename($_FILES["imgFile"]["name"]));
$stmt=$conn->prepare("INSERT INTO student_img (filename) VALUES(?)");
$stmt->bind_param("s",$filename);
if($stmt->execute()){
    echo"the file".$filename."has been uploaded and saved in the database";
}
    }
    else{
        echo "sorry there was an error";
    }
    }
}




?>