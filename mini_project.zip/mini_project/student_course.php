<?php
include "connection.php";

$successMsg = "";
$errorMsg = "";
$formSubmitted = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $formSubmitted = true;
    $courseName = $conn->real_escape_string($_POST['courseName']);
    $courseTeacher = $conn->real_escape_string($_POST['courseTeacher']);
    $teacherPhone = $conn->real_escape_string($_POST['teacherPhone']);
    $teacherAddress = $conn->real_escape_string($_POST['teacherAddress']);

    $checkSql = $conn->prepare("SELECT * FROM student_course WHERE course_name = ?");
    $checkSql->bind_param("s", $courseName);
    $checkSql->execute();
    $result = $checkSql->get_result();

    if ($result->num_rows > 0) {
        $errorMsg = "Error: Course name already exists";
    } else {
        $insertSql = $conn->prepare("INSERT INTO student_course(course_name, course_teacher, teacher_phone_no, teacher_address) VALUES (?, ?, ?, ?)");
        $insertSql->bind_param("ssss", $courseName, $courseTeacher, $teacherPhone, $teacherAddress);

        if ($insertSql->execute()) {
            $successMsg = "Course and data added successfully";
            // Redirect to course_fetch.php
            header("Location: course_fetch.php");
            exit();
        } else {
            $errorMsg = "Error: " . $insertSql->error;
        }
    }
    $checkSql->close();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register courses</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }

        h2 {
            color: #007bff;
        }

        label {
            color: #495057;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .alert {
            margin-top: 20px;
        }
    </style>
</head>

<body>

    <?php
    // Display messages only if the form has been submitted
    if ($formSubmitted) {
        if (!empty($successMsg)) {
            echo "<p style='color: green;'>$successMsg</p>";
        } elseif (!empty($errorMsg)) {
            echo "<p style='color: red;'>$errorMsg</p>";
        }
    }
    ?>

    <div class="container col-md-6 col-sm-10">
        <h2 class="text-center mb-4">Register courses</h2>
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">

            <div class="form-group">
                <label for="courseName">Course Name</label>
                <input type="text" class="form-control" id="course_name" name="courseName"
                    placeholder="Enter Course Name">
            </div>
            <div class="form-group">
                <label for="courseTeacher">course Teacher</label>
                <input type="text" class="form-control" id="courseTeacher" name="courseTeacher"
                    placeholder="Enter teachers course">
            </div>
            <div class="form-group">
                <label for="teacherPhone">Teachers Phone number</label>
                <input type="text" class="form-control" id="teacherPhone" name="teacherPhone"
                    placeholder="Enter teachers phone no">
            </div>
            <div class="form-group">
                <label for="teacherAddress">Teachers Address</label>
                <input type="text" class="form-control" id="teacherAddress" name="teacherAddress"
                    placeholder="Enter teachers Address">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

</body>

</html>

