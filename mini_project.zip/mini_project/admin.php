<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 1) {
    header("Location: login.php");
    exit();
}

include "connection.php"; 

// Fetch total number of students
$sqlStudents = "SELECT COUNT(*) as total_students FROM student_profile WHERE role = 2";
$resultStudents = $conn->query($sqlStudents);
$rowStudents = $resultStudents->fetch_assoc();
$totalStudents = $rowStudents['total_students'];

// Fetch total number of teachers from student_course table
$sqlTeachers = "SELECT COUNT(DISTINCT course_teacher) as total_teachers FROM student_course";
$resultTeachers = $conn->query($sqlTeachers);
$rowTeachers = $resultTeachers->fetch_assoc();
$totalTeachers = $rowTeachers['total_teachers'];

// Fetch total number of courses
$sqlCourses = "SELECT COUNT(*) as total_courses FROM student_course";
$resultCourses = $conn->query($sqlCourses);
$rowCourses = $resultCourses->fetch_assoc();
$totalCourses = $rowCourses['total_courses'];
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
   
    <style>

body {
            font-family: 'Roboto', sans-serif;
        }

        .dashboard-box {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .total-count {
            font-size: 24px;
            font-weight: 700;
            color: #007bff;
        }
         

footer {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 39px;
}

footer .col {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 20px;
}

footer .logo {
    margin-bottom: 30px;
}

footer h4 {
    font-size: 14px;
    padding-bottom: 20px;
}

footer p {
    font-size: 13px;
    margin: 0 0 8px 0;
}

footer a {
    font-size: 13px;
    text-decoration: none;
    color: #222;
    margin-bottom: 10px;
}

footer .follow {
    margin-top: 20px;
}

footer .follow i {
    color: #465b52;
    padding-right: 4px;
    cursor: pointer;
}

footer .install.row img {
    border: 1px solid #088178;
    border-radius: 6px;
}

footer .install img {
    margin: 10px 0 15px 0;
}
footer .follow i:hover,
footer a:hover {
    color: #088178;
}

footer .copyright {
    width: 100%;
    text-align: center;
}
  body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        .container {
            max-width: 400px;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

     

        h2 {
            color: #007bff;
        }

        label {
            color: #495057;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .alert {
            margin-top: 20px;
        }


        .container {
            max-width: 1000px; /* Set a wider maximum width */
            margin: 0 auto; /* Center the content horizontally */
        }

        /* Enhancing box styles */
        .dashboard-box {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center; /* Center text in boxes */
        }

        .total-count {
            font-size: 36px; /* Increase font size */
            font-weight: 700;
            color: #007bff;
            margin-bottom: 10px; /* Adjust spacing */
        }
    </style>
</head>

<body>
<!-- <section id="header">
        <div>
            <a href="#"><img src="img/logo.png" class="logo" alt=""> </a>
        </div>
        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="zone.php">Student zone</a></li>
                <li><a href="admission.php">Admissions</a></li>
                <li><a  href="contact.php">Contact</a></li>
                
                    <li><a href="student_profile.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> -->
                 
             
            </ul>
        </div>
        
    </section> 
    <header>
    <div>
            <?php include('navbar.php'); ?>
        </div>
    </header>
    <div class="container mt-5">
        <h2>Welcome, <?php echo isset($_SESSION['name']) ? $_SESSION['name'] : ''; ?> (Admin)!</h2>
        <p>This is the admin dashboard.</p>

        <div class="row">
            <div class="col-md-4">
                <div class="dashboard-box">
                    <p class="total-count"><?php echo $totalStudents; ?></p>
                    <p>Total Number of Students</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-box">
                    <p class="total-count"><?php echo $totalTeachers; ?></p>
                    <p>Total Number of Teachers</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-box">
                    <p class="total-count"><?php echo $totalCourses; ?></p>
                    <p>Total Number of Courses</p>
                </div>
            </div>
        </div>

        <a href="course_fetch.php" class="btn btn-primary">Manage Courses</a>
        <a href="dept_fetch.php" class="btn btn-primary">Manage Departments</a>
        <a href="student_fetch.php" class="btn btn-primary">Manage Students</a>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>


   
    <footer class="section-p1">
        <div class="col">
            <!-- <img class="logo" src="img/logo.png" alt=""> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> Himachal Pradesh Technical University</p>
            <p><strong>Phone:</strong> +91 7018441050 / 01905-268008</p>
            <p><strong>Hours:</strong> 10:00-18:00 Mon-Sat</p>
            <div class="follow">
                <h4>follow us</h4>
            </div>
            <div class="icon">
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-pinterest-p"></i>
                <i class="fab fa-youtube"></i>
                <i class="fab fa-linkedin-in"></i>
            </div>

        </div>
        <div class="col">
            <h4>About</h4>
            <a href="#">About us</a>
            <a href="#">Admissions</a>
            <a href="#">Primary Policy</a>
            <a href="#">Terms & conditions</a>
            <a href="#">Contact us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign-in</a>
            <a href="#">Courses offered</a>
            <a href="#">Scholarships</a>
            <a href="#">Results</a>
            <a href="#">Help</a>
        </div>
        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google play</p>
            <div class="row"></div>
            <img src="img/app.jpg" alt="">
            <img src="img/play.jpg" alt="">
            <p>Secured Payment Gateways</p>
            <img src="img/pay.png" alt="">
        </div>
        <div class="copyright">
            <p>&copy Himachal Pradesh Technical University-2023</p>
        </div>
    </footer>
    <!-- Bootstrap JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>












