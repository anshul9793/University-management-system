






<?php
include('connection.php');
session_start();

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['username']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>University management system</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
</head>

<body>
    <section id="header">
        <div>
            <a href="#"><img src="img/logo.png" class="logo" alt=""> </a>
        </div>
        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="zone.php">Student zone</a></li>
                <li><a href="admission.php">Admissions</a></li>
                <li><a href="contact.php">Contact</a></li>
                <?php if ($isLoggedIn) { ?>
                    <li><a href="student_profile.php">Welcome, <?php echo $_SESSION['username']; ?></a></li>
                    <li><a href="logout.php">Logout</a></li>
                <?php } else { ?>
                    <li><a href="student_profile.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                <?php } ?>
            </ul>
        </div>
    </section>
    <section id="hero">
        <h4>Welcome to Himachal Pradesh Technical University</h4>
        <h2>A State Government University</h2>
        <h1>Hamirpur Himachal Pradesh</h1>
        <!-- Other content -->
    </section>
    <section id="newsletter" class="section-p1 section-m1">
        <div class="newstext">
            <h4>Sign Up For Admission</h4>
            <p> Get E-mail Updates about our latest Courses and <span> scholarships</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="your email address">
            <button class="normal"><a href="student_profile.php" class="sign">Sign Up</a></button>
        </div>
    </section>
    <!-- Other sections of your HTML page -->

    <footer class="section-p1">
        <div class="col">
            <!-- <img class="logo" src="img/logo.png" alt=""> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> Himachal Pradesh Technical University</p>
            <p><strong>Phone:</strong> +91 7018441050 / 01905-268008</p>
            <p><strong>Hours:</strong> 10:00-18:00 Mon-Sat</p>
            <div class="follow">
                <h4>follow us</h4>
            </div>
            <div class="icon">
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-pinterest-p"></i>
                <i class="fab fa-youtube"></i>
                <i class="fab fa-linkedin-in"></i>
            </div>

        </div>
        <div class="col">
            <h4>About</h4>
            <a href="#">About us</a>
            <a href="#">Admissions</a>
            <a href="#">Primary Policy</a>
            <a href="#">Terms & conditions</a>
            <a href="#">Contact us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign-in</a>
            <a href="#">Courses offered</a>
            <a href="#">Scholarships</a>
            <a href="#">Results</a>
            <a href="#">Help</a>
        </div>
        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google play</p>
            <div class="row"></div>
            <img src="img/app.jpg" alt="">
            <img src="img/play.jpg" alt="">
            <p>Secured Payment Gateways</p>
            <img src="img/pay.png" alt="">
        </div>
        <div class="copyright">
            <p>&copy Himachal Pradesh Technical University-2023</p>
        </div>
    </footer>

    <?php
    if ($isLoggedIn) {
        echo "<script>alert('WELCOME TO Himachal Pradesh Technical University  -  $_SESSION[username]');</script>";
    }
    ?>
    <script src="script.js"></script>
</body>

</html>
