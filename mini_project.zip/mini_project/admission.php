<?php
session_start();
?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
   
    <style>
        #header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: whitesmoke;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.06);
    z-index: 999;
    position: sticky;
    top: 0;
    left: 0;
}

#header div a img {
    max-height: 70px;
}

#navbar {
    display: flex;
    align-items: center;
    justify-content: center;
}

#navbar li {
    list-style: none;
    padding: 0 20px;
    position: relative;
}

#navbar li a {
    text-decoration: none;
    font-size: 16px;
    font-weight: 400;
    color: black;
    transition: 0.3s ease;
}

#navbar li a:hover,
#navbar li a.active {
    color: rgb(125, 139, 231);
}

#navbar li a.active::after,
#navbar li a:hover::after {
    content: "";
    width: 30%;
    height: 2px;
    background: rgb(144, 125, 212);
    position: absolute;
    bottom: -4px;
    left: 20px;
}
footer {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 39px;
}

footer .col {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 20px;
}

footer .logo {
    margin-bottom: 30px;
}

footer h4 {
    font-size: 14px;
    padding-bottom: 20px;
}

footer p {
    font-size: 13px;
    margin: 0 0 8px 0;
}

footer a {
    font-size: 13px;
    text-decoration: none;
    color: #222;
    margin-bottom: 10px;
}

footer .follow {
    margin-top: 20px;
}

footer .follow i {
    color: #465b52;
    padding-right: 4px;
    cursor: pointer;
}

footer .install.row img {
    border: 1px solid #088178;
    border-radius: 6px;
}

footer .install img {
    margin: 10px 0 15px 0;
}
footer .follow i:hover,
footer a:hover {
    color: #088178;
}

footer .copyright {
    width: 100%;
    text-align: center;
}
  body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        .container {
            max-width: 400px;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

     

        h2 {
            color: #007bff;
        }

        label {
            color: #495057;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .alert {
            margin-top: 20px;
        }
        .container {
        max-width: 800px; 
        margin: 0 auto; 
    }
    </style>
</head>

<body>
<section id="header">
        <div>
            <a href="#"><img src="img/logo.png" class="logo" alt=""> </a>
        </div>
        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="zone.php">Student zone</a></li>
                <li><a href="admission.php">Admissions</a></li>
                <li><a  href="contact.php">Contact</a></li>
                
                    <!-- <li><a href="student_profile.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> -->
                 
             
            </ul>
        </div>
        
    </section>
    
    <div class="container">
        <div class="content">
            <h2>Welcome to Our University!</h2>
            <p>Welcome to the Himachal Pradesh Technical University, where we strive to provide quality education...</p>

            <!-- Content about scholarships -->
            <h3>Scholarships</h3>
            <p>At HPTU, we believe in supporting our students' academic endeavors by offering various scholarship programs...</p>
            <p>Our scholarships cater to students with exceptional academic achievements, financial needs, and outstanding talents...</p>
            <p>These scholarships aim to reduce the financial burden on students, enabling them to focus on their studies...</p>

            <!-- Additional content or paragraphs can be added here -->

            <div class="apply-now">
                <h3>Apply Now!</h3>
                <p>If you're interested in applying for our scholarships or have any queries regarding the application process...</p>
                <p>Contact our admissions office or visit our website for more information.</p>
            </div>
        </div>
    </div>


        <!-- Display messages here if needed -->
    </div>
    <footer class="section-p1">
        <div class="col">
            <!-- <img class="logo" src="img/logo.png" alt=""> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> Himachal Pradesh Technical University</p>
            <p><strong>Phone:</strong> +91 7018441050 / 01905-268008</p>
            <p><strong>Hours:</strong> 10:00-18:00 Mon-Sat</p>
            <div class="follow">
                <h4>follow us</h4>
            </div>
            <div class="icon">
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-pinterest-p"></i>
                <i class="fab fa-youtube"></i>
                <i class="fab fa-linkedin-in"></i>
            </div>

        </div>
        <div class="col">
            <h4>About</h4>
            <a href="#">About us</a>
            <a href="#">Admissions</a>
            <a href="#">Primary Policy</a>
            <a href="#">Terms & conditions</a>
            <a href="#">Contact us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign-in</a>
            <a href="#">Courses offered</a>
            <a href="#">Scholarships</a>
            <a href="#">Results</a>
            <a href="#">Help</a>
        </div>
        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google play</p>
            <div class="row"></div>
            <img src="img/app.jpg" alt="">
            <img src="img/play.jpg" alt="">
            <p>Secured Payment Gateways</p>
            <img src="img/pay.png" alt="">
        </div>
        <div class="copyright">
            <p>&copy Himachal Pradesh Technical University-2023</p>
        </div>
    </footer>
    <!-- Bootstrap JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>










