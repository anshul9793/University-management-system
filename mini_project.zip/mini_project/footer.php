

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>University management system</title>
    <link rel="stylesheet" href="footer.css" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <style>
    
    </style>
</head>

<body>
<footer class="section-p1">
        <div class="col">
            <!-- <img class="logo" src="img/logo.png" alt=""> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> Himachal Pradesh Technical University</p>
            <p><strong>Phone:</strong> +91 7018441050 / 01905-268008</p>
            <p><strong>Hours:</strong> 10:00-18:00 Mon-Sat</p>
            <div class="follow">
                <h4>follow us</h4>
            </div>
            <div class="icon">
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-pinterest-p"></i>
                <i class="fab fa-youtube"></i>
                <i class="fab fa-linkedin-in"></i>
            </div>

        </div>
        <div class="col">
            <h4>About</h4>
            <a href="#">About us</a>
            <a href="#">Admissions</a>
            <a href="#">Primary Policy</a>
            <a href="#">Terms & conditions</a>
            <a href="#">Contact us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign-in</a>
            <a href="#">Courses offered</a>
            <a href="#">Scholarships</a>
            <a href="#">Results</a>
            <a href="#">Help</a>
        </div>
        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google play</p>
            <div class="row"></div>
            <img src="img/app.jpg" alt="">
            <img src="img/play.jpg" alt="">
            <p>Secured Payment Gateways</p>
            <img src="img/pay.png" alt="">
        </div>
        <div class="copyright">
            <p>&copy Himachal Pradesh Technical University-2023</p>
        </div>
    </footer>

                </body>
                </html>