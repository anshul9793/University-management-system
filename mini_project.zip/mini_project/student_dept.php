<?php
include "connection.php";
$successMsg = "";
$errorMsg = "";
$formSubmitted = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $formSubmitted = true;

    $departmentName = $conn->real_escape_string($_POST['departmentName']);
    $departmentHOD = $conn->real_escape_string($_POST['departmentHOD']);
    $hodPhone = $conn->real_escape_string($_POST['hodPhone']);
    $hodAddress = $conn->real_escape_string($_POST['hod_address']);

    // Check if the course already exists.
    $checkSql = $conn->prepare("SELECT * FROM student_dept WHERE dept_name = ?");
    $checkSql->bind_param("s", $departmentName);
    $checkSql->execute();
    $result = $checkSql->get_result();

    if ($result->num_rows > 0) {
        // Already exists
        $errorMsg = "Error: dept name already exists.";
    } else {
        // Insert new records
        $insertSql = $conn->prepare("INSERT INTO student_dept (dept_name, dept_hod, hod_phone_no, hod_address) VALUES (?, ?, ?, ?)");
        $insertSql->bind_param("ssss", $departmentName, $departmentHOD, $hodPhone, $hodAddress);

        if ($insertSql->execute()) {
            $successMsg = "Dept added successfully";

            // Redirect to dept_fetch.php
            header("Location: dept_fetch.php");
            exit(); // Ensure that no further code is executed after the redirection
        } else {
            $errorMsg = "Error: " . $insertSql->error;
        }
    }
    $checkSql->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register Departments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }

        h2 {
            color: #007bff;
        }

        label {
            color: #495057;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .alert {
            margin-top: 20px;
        }
    </style>
</head>

<body>

    
    <?php
        // Display messages only if the form has been submitted
        if ($formSubmitted) {
            if (!empty($successMsg)) {
                echo "<p style='color: green;'>$successMsg</p>";
            } elseif (!empty($errorMsg)) {
                echo "<p style='color: red;'>$errorMsg</p>";
            }
        }
        ?>

<div class="container col-md-6 col-sm-10">
        <h2 class="text-center mb-4">Register departments</h2>
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
        
        <div class="form-group">
            <label for="deptName">Department Name</label>
            <input type="text" class="form-control" id="dept_name"  name="departmentName" placeholder="Enter Department Name">
        </div>
        <div class="form-group">
            <label for="deptHead">Department Head</label>
            <input type="text" class="form-control" id="deptHead" name="departmentHOD" placeholder="Enter Department Head">
        </div>
        <div class="form-group">
            <label for="hodPhone">HOD Phone</label>
            <input type="text" class="form-control" id="deptHead" name="hodPhone" placeholder="Enter Hod phone no.">
        </div>
        <div class="form-group">
            <label for="hod_address">HOd Address</label>
            <input type="text" class="form-control" id="hod_address" name="hod_address" placeholder="Enter Hod address">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>



</body>
</html>
