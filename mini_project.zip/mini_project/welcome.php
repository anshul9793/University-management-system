<?php
session_start();

include "connection.php"; // Include your database connection file

// Check if the user is logged in
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];

    // SQL query to get the logged-in user's profile
    $sql = "SELECT 
    student_profile.*, 
    student_img.filename AS filename,  
    student_dept.dept_name AS dept_name, 
    student_course.course_name AS course_name,
    student_profile.sname AS name,
    student_profile.address AS address, -- Include the address column
    student_profile.state AS state -- Include the state column
FROM student_profile 
LEFT JOIN student_img ON student_profile.p_id = student_img.id  
LEFT JOIN student_dept ON student_profile.dept_id = student_dept.id 
LEFT JOIN student_course ON student_profile.course_id = student_course.id 
WHERE student_profile.username = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
?>



<?php
    } else {
        echo "<div class='container mt-5'><p>User profile not found.</p></div>";
    }
} else {
    echo "<div class='container mt-5'><p>Please log in to view this page.</p></div>";
}

$conn->close();
?>
<?php

include "connection.php";

$errorMsg = "";
$formSubmitted = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $formSubmitted = true;

    $loginData = $conn->real_escape_string($_POST['loginData']);
    $userPassword = $conn->real_escape_string($_POST['password']);

    // Fetch the user's data from the database
    $sql = "SELECT username, spassword, role, sname FROM student_profile WHERE username = ? OR email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $loginData, $loginData);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['spassword'];
        $username = $row['username'];
        $role = $row['role'];
        $fullName = $row['sname'];

        if (password_verify($userPassword, $hashedPassword)) {
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;
            $_SESSION['name'] = $fullName;

            if ($role == 1) {
                // Redirect admin to admin.php
                header("Location: admin.php");
            } elseif ($role == 2) {
                // Redirect student to welcome.php
                header("Location: welcome.php");
            }
        } else {
            $errorMsg = "Your username or password is incorrect.";
        }
    } else {
        $errorMsg = "User not found";
    }
    
    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>









<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
   
    <style>
          .profile-image {
            max-width: 100px;
            max-height: 100px;
            border-radius: 15%;
            margin-right: 10px;
        }
    
footer {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 39px;
}

footer .col {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 20px;
}

footer .logo {
    margin-bottom: 30px;
}

footer h4 {
    font-size: 14px;
    padding-bottom: 20px;
}

footer p {
    font-size: 13px;
    margin: 0 0 8px 0;
}

footer a {
    font-size: 13px;
    text-decoration: none;
    color: #222;
    margin-bottom: 10px;
}

footer .follow {
    margin-top: 20px;
}

footer .follow i {
    color: #465b52;
    padding-right: 4px;
    cursor: pointer;
}

footer .install.row img {
    border: 1px solid #088178;
    border-radius: 6px;
}

footer .install img {
    margin: 10px 0 15px 0;
}
footer .follow i:hover,
footer a:hover {
    color: #088178;
}

footer .copyright {
    width: 100%;
    text-align: center;
}
  body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        .container {
            max-width: 400px;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

     

        h2 {
            color: #007bff;
        }

        label {
            color: #495057;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .alert {
            margin-top: 20px;
        }
    </style>
</head>

<body>
<!-- <section id="header">
        <div>
            <a href="#"><img src="img/logo.png" class="logo" alt=""> </a>
        </div>
        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="zone.php">Student zone</a></li>
                <li><a href="admission.php">Admissions</a></li>
                <li><a  href="contact.php">Contact</a></li>
                
                     <li><a href="student_profile.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> -->
                 
             
            </ul>
        </div>
        
    </section> 
<header>
    <div>
            <?php include('navbar.php'); ?>
        </div>
    <div class="container mt-5">
    </header>
        <?php
        if ($role == 2) {
            echo "<div class='card'>
                    <div class='card-header'>
                        <img src='" . $row["filename"] . "' alt='Profile Image' class='profile-image'>
                        Student Profile
                    </div>
                    <div class='card-body'>
                        <h5 class='card-title'>" . htmlspecialchars($row["sname"]) . "</h5>
                        <p class='card-text'>
                            <strong>Username:</strong> " . htmlspecialchars($row["username"]) . "<br>
                            <strong>Email:</strong> " . htmlspecialchars($row["email"]) . "<br>
                            <strong>Department Name:</strong> " . htmlspecialchars($row["dept_name"]) . "<br>
                            <strong>Course Name:</strong> " . htmlspecialchars($row["course_name"]) . "<br>
                            <strong>Phone Number:</strong> " . $row["phone"] . "<br>
                            <strong>Gender:</strong> " . htmlspecialchars($row["gender"]) . "<br>
                            <strong>address:</strong> " . htmlspecialchars($row["address"]) . "<br>
                            <strong>state:</strong> " . htmlspecialchars($row["state"]) . "<br>
                            <strong>Date of Birth:</strong> " . $row["dob"] . "
                        </p>
                      <p>  <a href='edit_profile.php' class='btn btn-primary'>Edit Details</a></P>
                    </div>
                   
                </div>";
        } else {
            echo "<div class='card'>
                    <div class='card-header'>
                        Admin Profile
                    </div>
                   
                </div>";
        }
        ?>
        <div><a class='btn btn-primary' href='logout.php'>Logout</a></div>
        
    </div>
   
   
    <footer class="section-p1">
        <div class="col">
            <!-- <img class="logo" src="img/logo.png" alt=""> -->
            <h4>Contact</h4>
            <p><strong>Address:</strong> Himachal Pradesh Technical University</p>
            <p><strong>Phone:</strong> +91 7018441050 / 01905-268008</p>
            <p><strong>Hours:</strong> 10:00-18:00 Mon-Sat</p>
            <div class="follow">
                <h4>follow us</h4>
            </div>
            <div class="icon">
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-pinterest-p"></i>
                <i class="fab fa-youtube"></i>
                <i class="fab fa-linkedin-in"></i>
            </div>

        </div>
        <div class="col">
            <h4>About</h4>
            <a href="#">About us</a>
            <a href="#">Admissions</a>
            <a href="#">Primary Policy</a>
            <a href="#">Terms & conditions</a>
            <a href="#">Contact us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign-in</a>
            <a href="#">Courses offered</a>
            <a href="#">Scholarships</a>
            <a href="#">Results</a>
            <a href="#">Help</a>
        </div>
        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google play</p>
            <div class="row"></div>
            <img src="img/app.jpg" alt="">
            <img src="img/play.jpg" alt="">
            <p>Secured Payment Gateways</p>
            <img src="img/pay.png" alt="">
        </div>
        <div class="copyright">
            <p>&copy Himachal Pradesh Technical University-2023</p>
        </div>
    </footer>
    <!-- Bootstrap JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>










